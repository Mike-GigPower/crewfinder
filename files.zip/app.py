"""
Crew Finder App
===================================
Flask backend serving the web UI and proxying requests to SmartStaff Solutions.

Run via menubar.py or directly:
    python3 app.py
"""

import json
import os
import re
import threading
from datetime import datetime, timedelta
from flask import Flask, jsonify, request, render_template, session, redirect, url_for
from bs4 import BeautifulSoup
import requests as http

app = Flask(__name__)
app.secret_key = os.urandom(24)

# ─── PATHS ────────────────────────────────────────────────────────────────────

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
CACHE_FILE  = os.path.join(BASE_DIR, "crew_cache.json")
BASE_URL    = "https://smartstaffsolutions.com"
CACHE_MAX_AGE_HRS = 24

# ─── CONFIG ───────────────────────────────────────────────────────────────────

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}

def save_config(data):
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=2)

# ─── SMARTSTAFF SESSION ───────────────────────────────────────────────────────

_ss_sessions = {}  # per-user SmartStaff sessions keyed by app session id

def get_ss_session():
    """Get or create a SmartStaff HTTP session for the current user."""
    sid = session.get("sid")
    if sid and sid in _ss_sessions:
        return _ss_sessions[sid]
    return None

def create_ss_session(username, password):
    """Login to SmartStaff and return a session object."""
    ss = http.Session()
    ss.headers.update({"User-Agent": "Mozilla/5.0"})
    resp = ss.post(f"{BASE_URL}/login", data={
        "action": "login",
        "username": username,
        "password": password,
        "x": "54",
        "y": "22"
    }, allow_redirects=True)
    # Check we landed on the dashboard not back on login
    if resp.url.rstrip("/").endswith("login"):
        return None, "Invalid credentials"
    return ss, None

# ─── CACHE ────────────────────────────────────────────────────────────────────

def load_cache():
    if not os.path.exists(CACHE_FILE):
        return {}, False
    try:
        with open(CACHE_FILE) as f:
            data = json.load(f)
        saved_at  = datetime.fromisoformat(data.get("saved_at", "2000-01-01"))
        age_hours = (datetime.now() - saved_at).total_seconds() / 3600
        return data.get("crew", {}), age_hours < CACHE_MAX_AGE_HRS
    except Exception:
        return {}, False

def save_cache(crew_profiles):
    with open(CACHE_FILE, "w") as f:
        json.dump({"saved_at": datetime.now().isoformat(), "crew": crew_profiles}, f)

# ─── SMARTSTAFF SCRAPERS ──────────────────────────────────────────────────────

VENUE_MAP = {
    "Marvel":         "Marvel",
    "Rod Laver":      "RLA",
    "Margaret Court": "MCA",
    "Festival Hall":  "Festival Hall",
    "John Cain":      "JCA",
    "Hamer Hall":     "Hamer Hall",
    "Palais":         "Palais",
    "Melbourne Exh":  "MCEC",
    "MCEC":           "MCEC",
}

def detect_venue(text):
    for substring, code in VENUE_MAP.items():
        if substring.lower() in text.lower():
            return code
    return None

def parse_shift(date_time_str, length_str):
    try:
        m = re.match(r"([A-Z][a-z]+ \d{1,2},\s*\d{4})\s*-\s*(\d{1,2}:\d{2})\s*Hrs", date_time_str.strip())
        if not m:
            return None, None
        start_dt = datetime.strptime(f"{m.group(1).strip()} {m.group(2)}", "%B %d, %Y %H:%M")
        lm = re.search(r"Length:\s*([\d.]+)\s*Hours?", length_str)
        if not lm:
            return None, None
        end_dt = start_dt + timedelta(hours=float(lm.group(1)))
        return start_dt, end_dt
    except Exception:
        return None, None

def scrape_calls(ss, url):
    """Scrape calls from a bookings/dashboard page."""
    resp = ss.get(url)
    soup = BeautifulSoup(resp.text, "html.parser")
    calls = []
    seen  = set()

    for link in soup.find_all("a", href=re.compile(r"bookings/(\d+)/callsheet/(\d+)")):
        href = link.get("href", "")
        m    = re.search(r"bookings/(\d+)/callsheet/(\d+)", href)
        if not m:
            continue
        booking_id = m.group(1)
        call_id    = m.group(2)
        if call_id in seen:
            continue
        seen.add(call_id)

        # Get row text
        row = link.find_parent("tr")
        row_text = row.get_text(" ", strip=True) if row else ""

        # Parse fields
        call_num_m = re.search(r"#(\d+)", row_text)
        date_m     = re.search(r"(\d{2}/\d{2}/\d{2})", row_text)
        time_m     = re.search(r"(\d{2}:\d{2})", row_text)
        length_m   = re.search(r"(\d+(?:\.\d+)?)\s*hrs?", row_text, re.I)
        booked_m   = re.search(r"(\d+)\s*/\s*(\d+)", row_text)

        # Get call type (text between time and length)
        call_name_m = re.search(r"\d{2}:\d{2}\s+(.+?)\s+\d+\s*hrs?", row_text, re.I)

        # Get venue from surrounding HTML
        venue = ""
        container = link.find_parent("table")
        if container:
            prev = container.find_previous(string=re.compile(r"Arena|Theatre|Hall|Centre|MCEC|Palais|Laver|Marvel|Cain"))
            if prev:
                venue = detect_venue(str(prev)) or ""

        booked   = int(booked_m.group(1)) if booked_m else 0
        required = int(booked_m.group(2)) if booked_m else 0

        calls.append({
            "booking_id": booking_id,
            "call_id":    call_id,
            "call_num":   call_num_m.group(1) if call_num_m else call_id,
            "date":       date_m.group(1) if date_m else "",
            "time":       time_m.group(1) if time_m else "",
            "length":     float(length_m.group(1)) if length_m else 0,
            "call_name":  call_name_m.group(1).strip() if call_name_m else "",
            "booked":     booked,
            "required":   required,
            "unfilled":   booked < required,
            "venue":      venue,
        })

    return calls

def scrape_call_details(ss, booking_id, call_id):
    """Get call date/time/duration/venue from callsheet."""
    resp = ss.get(f"{BASE_URL}/bookings/{booking_id}/callsheet/{call_id}")
    soup = BeautifulSoup(resp.text, "html.parser")

    date_el   = soup.find("input", {"name": "start_date"})
    time_el   = soup.find("input", {"name": "start_time"})
    length_el = soup.find("input", {"name": "length"})
    name_el   = soup.find("input", {"name": "name"})
    crew_el   = soup.find("input", {"name": "crew_required"})

    date_val   = date_el["value"].strip()   if date_el   else ""
    time_val   = time_el["value"].strip()   if time_el   else ""
    length_val = length_el["value"].strip() if length_el else "0"
    name_val   = name_el["value"].strip()   if name_el   else ""
    crew_req   = int(crew_el["value"])      if crew_el   else 0

    try:
        time_clean = time_val[:5]
        start_dt   = datetime.strptime(f"{date_val.strip()} {time_clean}", "%B %d, %Y %H:%M")
        end_dt     = start_dt + timedelta(hours=float(length_val))
    except Exception as e:
        return None, str(e)

    venue = detect_venue(resp.text) or ""

    # Crew required from banner
    banner_m = re.search(r"THIS CALL REQUIRES (\d+) CREW", resp.text)
    crew_required = int(banner_m.group(1)) if banner_m else crew_req

    return {
        "call_name":     name_val,
        "start_dt":      start_dt.isoformat(),
        "end_dt":        end_dt.isoformat(),
        "length_hrs":    float(length_val),
        "venue":         venue,
        "crew_required": crew_required,
        "date_str":      start_dt.strftime("%A %d %B %Y"),
        "start_str":     start_dt.strftime("%H:%M"),
        "end_str":       end_dt.strftime("%H:%M"),
    }, None

def scrape_all_crew(ss):
    """Get all crew from all pages."""
    all_crew = []
    page_num = 0
    while True:
        resp = ss.get(f"{BASE_URL}/crew?p={page_num}&")
        soup = BeautifulSoup(resp.text, "html.parser")
        rows = soup.select("#crewcontent tr")
        page_crew = []
        for row in rows:
            name_link   = row.find("a", href=re.compile(r"add-call\.php.*userID="))
            manage_link = row.find("a", href=re.compile(r"crew/manage/"))
            phone_link  = row.find("a", href=re.compile(r"^tel:"))
            if not name_link or not manage_link:
                continue
            name  = name_link.get_text(strip=True)
            href  = manage_link.get("href", "")
            m     = re.search(r"crew/manage/(\d+)", href)
            phone = phone_link.get_text(strip=True) if phone_link else ""
            if m and name:
                page_crew.append({"name": name, "id": m.group(1), "phone": phone})

        if not page_crew:
            break
        all_crew.extend(page_crew)

        # Check for NEXT
        has_next = any(
            a.get_text(strip=True).upper() == "NEXT"
            for a in soup.find_all("a", href=re.compile(r"crew\?p="))
        )
        if not has_next:
            break
        page_num += 1

    return all_crew

def scrape_crew_profile(ss, crew_id):
    """Get groups and rating for a crew member."""
    resp  = ss.get(f"{BASE_URL}/crew/manage/{crew_id}?page=1")
    soup  = BeautifulSoup(resp.text, "html.parser")
    groups = [el.get_text(strip=True) for el in soup.select("div.crewgroup") if el.get_text(strip=True)]
    # Rating is set via JS: "var rating = N" — stars are all off in raw HTML
    rating_m = re.search(r"var rating\s*=\s*(\d+)", resp.text)
    rating   = int(rating_m.group(1)) if rating_m else 0
    return groups, rating

def get_crew_shifts(ss, crew_id, today):
    """Get confirmed future shifts for a crew member from page 1.
    
    The plain HTTP response wraps data in <b> tags:
      <b>May 24, 2026 - 22:00 Hrs</b><br /><b>Length:</b> 4 Hours ... Confirmed
    """
    resp    = ss.get(f"{BASE_URL}/crew/manage/{crew_id}?page=1")
    content = resp.text
    
    # Match the HTML format: <b>DATE - TIME Hrs</b> ... Length: N Hours ... Confirmed
    pattern = r"<b>([A-Z][a-z]+ \d{1,2},\s*\d{4}\s*-\s*\d{1,2}:\d{2}\s*Hrs)</b>.*?<b>Length:</b>\s*([\d.]+)\s*Hours?.*?(Confirmed|Declined|Pending)"
    matches = list(re.finditer(pattern, content, re.DOTALL))
    
    shifts  = []
    seen    = set()
    for match in matches:
        date_time_str = match.group(1)
        length_str    = f"Length: {match.group(2)} Hours"
        status        = match.group(3)
        
        start_dt, end_dt = parse_shift(date_time_str, length_str)
        if not start_dt or not end_dt:
            continue
        if end_dt < today:
            continue
        if status.lower() != "confirmed":
            continue
        key = (start_dt, end_dt)
        if key in seen:
            continue
        seen.add(key)
        preceding = content[max(0, match.start()-300):match.start()]
        venue     = detect_venue(preceding)
        shifts.append({
            "start": start_dt.isoformat(),
            "end":   end_dt.isoformat(),
            "venue": venue or "",
        })
    return shifts

# ─── CONFLICT RULES ───────────────────────────────────────────────────────────

LONG_SHIFT_HRS  = 8
LONG_GAP_HRS    = 6
VENUE_GAP_HRS   = 2
MAX_24H_HRS     = 16

def check_conflict(shifts, target_start, target_end, target_venue):
    for s in shifts:
        shift_start = datetime.fromisoformat(s["start"])
        shift_end   = datetime.fromisoformat(s["end"])
        shift_venue = s.get("venue", "")
        shift_dur   = (shift_end - shift_start).total_seconds() / 3600

        # Rule 1: overlap
        if shift_start < target_end and shift_end > target_start:
            return True, f"Rule 1 - Overlap: {shift_start.strftime('%d %b %H:%M')}-{shift_end.strftime('%H:%M')} @ {shift_venue or '?'}"

        # Gap
        if target_start >= shift_end:
            gap = (target_start - shift_end).total_seconds() / 3600
        elif shift_start >= target_end:
            gap = (shift_start - target_end).total_seconds() / 3600
        else:
            continue

        # Rule 2: long shift gap
        if shift_dur >= LONG_SHIFT_HRS and gap < LONG_GAP_HRS:
            return True, f"Rule 2 - {shift_dur:.0f}hr shift needs {LONG_GAP_HRS}hr gap (only {gap:.1f}hrs): {shift_start.strftime('%d %b %H:%M')} @ {shift_venue or '?'}"

        # Rule 3: venue change
        if shift_venue and target_venue and shift_venue != target_venue and gap < VENUE_GAP_HRS:
            return True, f"Rule 3 - Venue change {shift_venue}→{target_venue} needs {VENUE_GAP_HRS}hr gap (only {gap:.1f}hrs)"

    # Rule 4: rolling 24hr window
    for win_start, win_end in [
        (target_end - timedelta(hours=24), target_end),
        (target_start, target_start + timedelta(hours=24)),
    ]:
        total = 0.0
        for s in shifts:
            ss = datetime.fromisoformat(s["start"])
            se = datetime.fromisoformat(s["end"])
            if se <= win_start or ss >= win_end:
                continue
            total += (min(se, win_end) - max(ss, win_start)).total_seconds() / 3600
        t_start = max(target_start, win_start)
        t_end   = min(target_end,   win_end)
        if t_end > t_start:
            total += (t_end - t_start).total_seconds() / 3600
        if total > MAX_24H_HRS:
            return True, f"Rule 4 - Would work {total:.1f}hrs in 24hr window (max {MAX_24H_HRS}hrs)"

    return False, ""

# ─── ROUTES ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    if not session.get("sid") or not get_ss_session():
        return redirect(url_for("login"))
    return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        remember = request.form.get("remember") == "on"

        ss, err = create_ss_session(username, password)
        if err:
            error = err
        else:
            import uuid
            sid = str(uuid.uuid4())
            session["sid"] = sid
            session.permanent = remember
            _ss_sessions[sid] = ss

            if remember:
                cfg = load_config()
                cfg["username"] = username
                cfg["password"] = password
                save_config(cfg)

            return redirect(url_for("index"))

    # Pre-fill from config
    cfg = load_config()
    return render_template("login.html",
        error=error,
        saved_username=cfg.get("username", "")
    )

@app.route("/logout")
def logout():
    sid = session.pop("sid", None)
    if sid:
        _ss_sessions.pop(sid, None)
    return redirect(url_for("login"))

@app.route("/api/calls")
def api_calls():
    ss = get_ss_session()
    if not ss:
        return jsonify({"error": "Not logged in"}), 401

    # Load from dashboard only (unfilled calls)
    calls = scrape_calls(ss, f"{BASE_URL}/dash")
    return jsonify({"calls": calls})

@app.route("/api/call/<booking_id>/<call_id>")
def api_call_details(booking_id, call_id):
    ss = get_ss_session()
    if not ss:
        return jsonify({"error": "Not logged in"}), 401
    details, err = scrape_call_details(ss, booking_id, call_id)
    if err:
        return jsonify({"error": err}), 500
    return jsonify(details)

@app.route("/api/availability", methods=["POST"])
def api_availability():
    ss = get_ss_session()
    if not ss:
        return jsonify({"error": "Not logged in"}), 401

    data            = request.json
    booking_id      = data["booking_id"]
    call_id         = data["call_id"]
    target_start    = datetime.fromisoformat(data["start_dt"])
    target_end      = datetime.fromisoformat(data["end_dt"])
    target_venue    = data.get("venue", "")
    required_groups = data.get("required_groups", [])
    min_rating      = int(data.get("min_rating", 3))

    today = datetime.now()

    # Load crew list
    all_crew = scrape_all_crew(ss)

    # Load cache
    cache, is_fresh = load_cache()
    updated_cache   = dict(cache)

    available = []
    conflicts  = []
    skipped    = []

    for crew in all_crew:
        cid = crew["id"]

        # Get profile from cache or web
        if cid in cache:
            groups = cache[cid]["groups"]
            rating = cache[cid]["rating"]
        else:
            groups, rating = scrape_crew_profile(ss, cid)
            updated_cache[cid] = {"groups": groups, "rating": rating}

        crew["groups"] = groups
        crew["rating"] = rating

        # Filter
        reasons = []
        if rating < min_rating:
            reasons.append(f"Rating {rating} < {min_rating}")
        groups_lower = [g.lower() for g in groups]
        for cert in required_groups:
            if cert.lower() not in groups_lower:
                reasons.append(f"Missing: {cert}")

        if reasons:
            skipped.append({**crew, "reason": " | ".join(reasons)})
            continue

        # Check shifts
        shifts = get_crew_shifts(ss, cid, today)
        conflict, reason = check_conflict(shifts, target_start, target_end, target_venue)

        # Nearby shifts for timeline
        nearby = [
            s for s in shifts
            if abs((datetime.fromisoformat(s["start"]) - target_start).total_seconds()) <= 3 * 86400
        ]

        if conflict:
            conflicts.append({**crew, "detail": reason, "shifts": nearby})
        else:
            conflicts_str = ""
            available.append({**crew, "detail": "", "shifts": nearby})

    # Save cache
    save_cache(updated_cache)

    # Sort available by rating desc
    available.sort(key=lambda x: x["rating"], reverse=True)
    conflicts.sort(key=lambda x: x["rating"],  reverse=True)

    return jsonify({
        "available": available,
        "conflicts":  conflicts,
        "skipped":    skipped,
        "call_id":    call_id,
        "booking_id": booking_id,
    })

@app.route("/api/cache/status")
def api_cache_status():
    cache, is_fresh = load_cache()
    age_str = "No cache"
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE) as f:
                d = json.load(f)
            saved = datetime.fromisoformat(d.get("saved_at", "2000-01-01"))
            hours = (datetime.now() - saved).total_seconds() / 3600
            age_str = f"{hours:.1f} hours ago"
        except Exception:
            pass
    return jsonify({
        "fresh":    is_fresh,
        "profiles": len(cache),
        "age":      age_str,
    })

@app.route("/api/cache/refresh", methods=["POST"])
def api_cache_refresh():
    """Trigger a full cache refresh in the background."""
    ss = get_ss_session()
    if not ss:
        return jsonify({"error": "Not logged in"}), 401

    def refresh():
        all_crew = scrape_all_crew(ss)
        new_cache = {}
        for crew in all_crew:
            groups, rating = scrape_crew_profile(ss, crew["id"])
            new_cache[crew["id"]] = {"groups": groups, "rating": rating}
        save_cache(new_cache)

    threading.Thread(target=refresh, daemon=True).start()
    return jsonify({"status": "Refresh started in background"})

@app.route("/api/groups")
def api_groups():
    return jsonify({"groups": [
        "W.B.", "PhD.", "CI Card", "JOAT", "Audio", "Backline",
        "Fork", "Lights", "Set/Stg", "Spot", "Truck", "Wardrobe",
        "EWP", "MCEC", "MCG", "MOPT"
    ]})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5001, debug=False)
